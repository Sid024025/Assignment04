#include <stdio.h>
#include <string.h>

int main() {
    char buffer[16];   // Buffer size = 16 characters
    char input[100];   // Larger input buffer

    // Ask user for input
    printf("Enter some text: ");
    gets(input);   // (unsafe, used for demo)

    // Unsafe copy (no size check)
    strcpy(buffer, input);

    // Print result
    printf("Buffer contains: %s\n", buffer);

    return 0;
}


/*
1) What happens with long input?

If the user enters more than 16 characters,
the extra data overflows the buffer and starts
overwriting adjacent memory.

This may cause:
- Program crash (segmentation fault)
- Unexpected behavior
- Memory corruption

2) Why is this dangerous?

Because attackers can:
- Overwrite important memory
- Change program execution flow
- Execute malicious code

This is a common vulnerability used in exploitation.

3) How would you fix it?

Use safer functions with bounds checking:

Example:
    fgets(input, sizeof(input), stdin);
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[15] = '\0';

Or simply:
    fgets(buffer, sizeof(buffer), stdin);

This prevents writing beyond buffer size.


*/
