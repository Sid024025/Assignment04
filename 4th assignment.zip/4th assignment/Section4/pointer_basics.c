#include <stdio.h>

int main() {
    // Create integer variable
    int port = 80;

    // Create pointer to port
    int *ptr = &port;

    // Print port value using variable
    printf("Port value (variable): %d\n", port);

    // Print port value using pointer
    printf("Port value (pointer): %d\n", *ptr);

    // Change port value using pointer
    *ptr = 443;

    // Print new value
    printf("New port value (variable): %d\n", port);
    printf("New port value (pointer): %d\n", *ptr);

    return 0;
}

// for execute and run
// gcc pointer_basics.c -o pointer_basics
// ./pointer_basics
