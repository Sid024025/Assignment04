#!/bin/bash

# Check if IP is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <target_ip>"
    exit 1
fi

TARGET=$1
DATE=$(date +%Y-%m-%d)
OUTPUT="scan_${TARGET}_${DATE}.txt"

# Common ports to scan
PORTS=(21 22 80 443 3306)

echo "Scanning $TARGET..." > $OUTPUT
echo "Scan date: $DATE" >> $OUTPUT
echo "-------------------------" >> $OUTPUT

OPEN_COUNT=0

# Loop through ports
for PORT in "${PORTS[@]}"; do
    timeout 1 bash -c "echo > /dev/tcp/$TARGET/$PORT" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "Port $PORT is OPEN" | tee -a $OUTPUT
        ((OPEN_COUNT++))
    else
        echo "Port $PORT is CLOSED" >> $OUTPUT
    fi
done

echo "-------------------------" >> $OUTPUT
echo "Total OPEN ports: $OPEN_COUNT" | tee -a $OUTPUT

# for excuteable and run
#chmod +x port_report.sh
#./port_report.sh <ip_address>