import socket
import time

# Take input
target = input("Enter target IP: ")
ports_input = input("Enter ports (comma-separated, e.g. 21,22,80): ")

# Convert ports to list of integers
ports = [int(p.strip()) for p in ports_input.split(",")]

# Start timer
start_time = time.time()

# Open output file
output_file = "scan_results.txt"
f = open(output_file, "w")

f.write(f"Scan results for {target}\n")
f.write("-" * 30 + "\n")

open_count = 0

# Scan ports
for port in ports:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)

    result = s.connect_ex((target, port))

    if result == 0:
        status = "OPEN"
        open_count += 1
    else:
        status = "CLOSED"

    line = f"Port {port}: {status}"
    print(line)
    f.write(line + "\n")

    s.close()

# End timer
end_time = time.time()
duration = round(end_time - start_time, 2)

f.write("-" * 30 + "\n")
f.write(f"Total OPEN ports: {open_count}\n")
f.write(f"Scan Duration: {duration} seconds\n")

f.close()

print("\nScan completed!")
print(f"Results saved to {output_file}")
print(f"Scan Duration: {duration} seconds")
