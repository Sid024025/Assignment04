import re

# Take password input
password = input("Enter your password: ")

score = 0
feedback = []

# Check length
if len(password) >= 8:
    score += 1
else:
    feedback.append("Use at least 8 characters.")

# Check uppercase
if re.search(r"[A-Z]", password):
    score += 1
else:
    feedback.append("Add at least one uppercase letter.")

# Check lowercase
if re.search(r"[a-z]", password):
    score += 1
else:
    feedback.append("Add at least one lowercase letter.")

# Check numbers
if re.search(r"[0-9]", password):
    score += 1
else:
    feedback.append("Include at least one number.")

# Check special characters
if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
    score += 1
else:
    feedback.append("Add at least one special character.")

# Determine strength
if score <= 2:
    strength = "Weak"
elif score <= 4:
    strength = "Medium"
else:
    strength = "Strong"

# Display results
print("\nPassword Strength:", strength)
print("Score:", score, "/ 5")

# Show recommendations
if feedback:
    print("\nRecommendations:")
    for tip in feedback:
        print("-", tip)
else:
    print("\nGreat! Your password is strong 💪")
