description = [[
Retrieves basic HTTP server information:
- HTTP status code
- Server header
- Page title
]]

author = "Your Name"
license = "Same as Nmap"
categories = {"discovery", "safe"}

-- Run only on HTTP ports
portrule = function(host, port)
    return port.protocol == "tcp" and (port.number == 80 or port.number == 8080)
end

action = function(host, port)
    local http = require "http"
    local shortport = require "shortport"

    -- Send HTTP GET request to "/"
    local response = http.get(host, port, "/")

    if not response then
        return "No response received"
    end

    local result = ""

    -- Extract status code
    if response.status then
        result = result .. "Status Code: " .. response.status .. "\n"
    end

    -- Extract Server header
    if response.header and response.header["server"] then
        result = result .. "Server: " .. response.header["server"] .. "\n"
    end

    -- Extract page title
    if response.body then
        local title = string.match(response.body, "<title>(.-)</title>")
        if title then
            result = result .. "Page Title: " .. title .. "\n"
        end
    end

    return result
end
