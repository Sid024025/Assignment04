import socket
import time
from datetime import datetime

# Simple vulnerability database
vuln_db = {
    21: "FTP may allow anonymous login",
    22: "SSH brute-force possible",
    80: "HTTP may be vulnerable to XSS/SQLi",
    443: "Check SSL/TLS configuration"
}

# Common service mapping
services = {
    21: "FTP",
    22: "SSH",
    80: "HTTP",
    443: "HTTPS"
}

# Scan a single port
def scan_port(target, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)

    result = s.connect_ex((target, port))
    s.close()

    return result == 0  # True if open

# Main program
target = input("Enter target IP: ")

ports = [21, 22, 80, 443]
results = []

start_time = time.time()

print(f"\nScanning {target}...\n")

for port in ports:
    is_open = scan_port(target, port)

    if is_open:
        service = services.get(port, "Unknown")
        vuln = vuln_db.get(port, "No known issues")

        print(f"Port {port}: OPEN ({service})")

        results.append({
            "port": port,
            "status": "OPEN",
            "service": service,
            "vuln": vuln
        })
    else:
        print(f"Port {port}: CLOSED")

end_time = time.time()
duration = round(end_time - start_time, 2)

# Generate HTML report
filename = f"report_{target}.html"

with open(filename, "w") as f:
    f.write(f"""
    <html>
    <head>
        <title>Security Audit Report</title>
        <style>
            body {{ font-family: Arial; }}
            table {{ border-collapse: collapse; width: 80%; }}
            th, td {{ border: 1px solid black; padding: 8px; }}
            th {{ background-color: #f2f2f2; }}
        </style>
    </head>
    <body>

    <h2>Security Audit Report</h2>
    <p><b>Target:</b> {target}</p>
    <p><b>Scan Time:</b> {datetime.now()}</p>
    <p><b>Duration:</b> {duration} seconds</p>

    <table>
        <tr>
            <th>Port</th>
            <th>Status</th>
            <th>Service</th>
            <th>Possible Vulnerability</th>
        </tr>
    """)

    for r in results:
        f.write(f"""
        <tr>
            <td>{r['port']}</td>
            <td>{r['status']}</td>
            <td>{r['service']}</td>
            <td>{r['vuln']}</td>
        </tr>
        """)

    f.write("""
    </table>

    </body>
    </html>
    """)

print(f"\nReport saved as {filename}")
print(f"Scan Duration: {duration} seconds")
